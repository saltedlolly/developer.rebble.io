package com.getpebble.pkat3;

public class Keys {

    public static final int KEY_CHOICE = 0;
    public static final int CHOICE_ROCK = 0;
    public static final int CHOICE_PAPER = 1;
    public static final int CHOICE_SCISSORS = 2;
    public static final int CHOICE_WAITING = 3;

    public static final int KEY_RESULT = 1;
    public static final int RESULT_LOSE = 0;
    public static final int RESULT_WIN = 1;
    public static final int RESULT_TIE = 2;

}
