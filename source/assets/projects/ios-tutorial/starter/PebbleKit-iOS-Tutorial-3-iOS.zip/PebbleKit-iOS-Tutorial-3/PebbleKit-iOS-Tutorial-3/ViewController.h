//
//  ViewController.h
//  PebbleKit-iOS-Tutorial-3
//
//  Created by Chris Lewis on 1/13/15.
//  Copyright (c) 2015 Pebble. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

// Function prototype
- (void)doMatch;
- (void)updateUI;

@end

