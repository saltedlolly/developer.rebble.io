//
//  main.m
//  PebbleKit-iOS-Tutorial-1
//
//  Created by Chris Lewis on 11/25/14.
//  Copyright (c) 2014 Pebble. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
