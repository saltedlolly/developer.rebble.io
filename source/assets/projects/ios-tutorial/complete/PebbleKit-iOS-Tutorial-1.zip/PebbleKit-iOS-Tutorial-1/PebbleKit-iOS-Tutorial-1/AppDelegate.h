//
//  AppDelegate.h
//  PebbleKit-iOS-Tutorial-1
//
//  Created by Chris Lewis on 11/25/14.
//  Copyright (c) 2014 Pebble. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PebbleKit/PebbleKit.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

- (PBWatch *)getConnectedWatch;

@end

